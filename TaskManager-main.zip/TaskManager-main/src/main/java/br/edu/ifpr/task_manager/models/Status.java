package br.edu.ifpr.task_manager.models;

public enum Status {
    EM_ANDAMENTO,
    CONCLUIDO,
    CANCELADO
}
